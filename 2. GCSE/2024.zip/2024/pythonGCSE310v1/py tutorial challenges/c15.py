#Program name: Level 1 Challenge 15 Name and blood type incomplete

lastname = input("Please enter your last name: ")
initial = input("Please enter your initial: ")
bloodType = input("Enter your blood type: ")

#Enter  statement to print information entered by the user in the format
#Name: Johnson F    Blood type: O negative

print("Name:",lastname,initial,"   ","Blood type:",bloodType)
