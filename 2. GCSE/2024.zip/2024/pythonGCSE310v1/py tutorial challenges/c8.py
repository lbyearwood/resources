#Program name: Level 1 Challenge 8 Program with syntax errors
# Correct the syntax errors in this program

print("This program contains syntax errors\n")

favourite_animal = "Giraffe"
scariestAnimal = "Lion"
print ("Favourite animal...", favourite_animal, "\n"
       "Scariest animal...." ,scariestAnimal)
