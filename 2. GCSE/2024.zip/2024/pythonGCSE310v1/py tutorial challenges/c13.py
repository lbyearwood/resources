maxLives = 3 # constant
livesRemaining = 2 # variables
cityPopulation = 5467292 # variables
rateOfGravity = 9.8 # constant