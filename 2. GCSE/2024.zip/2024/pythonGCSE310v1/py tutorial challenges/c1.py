print("'If at first you don't succeed, then sky diving isn't'"
      " for you \n- Steven Wright")