firstname = input("enter your first name")
surname = input("enter your surname")

print("Surname: "+surname+" First Name: "+firstname)