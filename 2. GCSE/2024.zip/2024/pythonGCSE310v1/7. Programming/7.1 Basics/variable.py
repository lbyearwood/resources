# Rules for naming variables
# variable names must be descriptive


number = 29
number = number * 12
number = 70
number = number / 4

print(number)