my_name = input("Enter your name")
print("Hello",my_name)