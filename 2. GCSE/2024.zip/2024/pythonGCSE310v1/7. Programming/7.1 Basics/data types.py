# these are variables below that store
# different data types

_string = "example"
_char = "g"
_integer = 23
_real_float = 34.5
_boolean = True