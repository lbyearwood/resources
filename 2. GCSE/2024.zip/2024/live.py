constant_DOB = "21/02/2008"
age = 14
constant_DOB = "11/02/2008"
age = 15